from django import forms
from .models import Student, Major, Course, Course_requirement, Enroll, Major_selection, Major_requirement, Requirement
# Assignment 6 imports Form and FileField
from django.forms import FileField, ModelForm


# Assignment 6 FileField class
class UploadForm(forms.Form):
    upload_file = FileField()


COURSE_CHOICES =()
# major form
class MajorForm(forms.ModelForm):
    class Meta:
        model = Major
        fields = ('major_name','total_hours')

# student form
class StudentForm(forms.ModelForm):
    class Meta:
        model = Student
        fields = ('first_name','last_name')

# course form
class CourseForm(forms.ModelForm):
    class Meta:
        model = Course
        fields = ('course_name','course_title','course_desc','credit_hours','prerequisite','semester')

# requirement form
class RequirementForm(forms.ModelForm):
    class Meta:
        model = Requirement
        fields = "__all__"

# major selection form
class MajorSelForm(forms.ModelForm):
    class Meta:
        model = Major_selection
        fields = "__all__"

# major requirement form
class MajorReqForm(forms.ModelForm):
    class Meta:
        model = Major_requirement
        fields = "__all__"

# enroll form
class EnrollForm(forms.ModelForm):
    class Meta:
        model = Enroll
        fields = "__all__"

# course requirement form
class CourseReqForm(forms.ModelForm):
    class Meta:
        model = Course_requirement
        fields = "__all__"
